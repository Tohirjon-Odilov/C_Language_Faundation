#include <stdio.h>

int main(){

	char belgi = '*';
	printf("\n%c %c %c %c\n", belgi, belgi, belgi, belgi);
	printf("%c %c %c\n", belgi,belgi,belgi);
	printf("%c %c\n", belgi, belgi);
	printf("%c\n", belgi);

	return 0;

}
