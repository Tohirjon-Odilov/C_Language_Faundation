#include <stdio.h>

int main(){

	int f = 100;
	int c = 35;
	printf("%d farangeyt selsiyga teng.\n", f, ((5/9)*(f-32))/10);
	printf("%d selsiy farangeytga teng.\n", c, (9/5)*c+32);
	return 0;

}
