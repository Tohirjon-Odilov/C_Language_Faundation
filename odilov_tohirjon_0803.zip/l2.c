#include <stdio.h>

int main()
{
	char text[32];

	

	return 0;
}
