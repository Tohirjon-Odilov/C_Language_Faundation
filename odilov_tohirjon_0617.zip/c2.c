#include <stdio.h>

int main(){

    int num = 1000;

    while(num >= 1){
        printf("%d\n",num);
        --num;
    }

    return 0;
}

