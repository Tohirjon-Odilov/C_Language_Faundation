#include <stdio.h>

int main(){

    int num = 300;

    while(num >= 150){
        printf("%d\n",num);
        --num;
    }

    return 0;
}

