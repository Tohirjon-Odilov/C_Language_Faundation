#include <stdio.h>

int main(){

    int num = 200;

    while(num >= -500){
        printf("%d\n",num);
        --num;
    }

    return 0;
}

