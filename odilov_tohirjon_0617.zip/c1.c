#include <stdio.h>

int main(){

    int num = 1;

	while(num <= 800){
		printf("%d\n",num);
		++num;

	}

    return 0;
}

