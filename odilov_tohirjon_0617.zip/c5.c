#include <stdio.h>

int main(){

    int num = -400;

    while(num <= 250){
        printf("%d\n",num);
        ++num;
    }

    return 0;
}

