#include <stdio.h>

int main(){

	int nums[] = {2, -8, 90, -4, -8, 32, 44, 21};

	printf("%d\n", nums[5]);

	return 0;
}
