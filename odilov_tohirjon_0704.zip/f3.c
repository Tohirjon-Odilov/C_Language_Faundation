#include <stdio.h>

int main(){

	int nums[] = {5, 8, 4, 7, 2, 3, 9, 0, 0};

	printf("%d\n", nums[1]);

	return 0;
}
