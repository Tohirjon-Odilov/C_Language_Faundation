#include <stdio.h>

int main(){

    int num = 240;
    int i = 100;

    while(i <= num){
        if(i % 2)
            printf("%d\n", i);
        i++;
    }

}
