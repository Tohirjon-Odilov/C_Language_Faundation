#include <stdio.h>

int main(){

	int gradus;

	printf("Gradus kiriting: ");
	scanf("%d", &gradus); printf("%d", gradus % 360);

	return 0;

}
