#include <stdio.h>

int main(){

	int num = 3;

	printf("Son kiriting: ");
	scanf("%d", &num); printf("%d ning 5ga ko'paytmasi %d ga teng.\n", num, num*5);

	return 0;

}
