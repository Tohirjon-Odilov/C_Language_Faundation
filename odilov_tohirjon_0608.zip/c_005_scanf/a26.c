#include <stdio.h> 

int main(){

	int a,b,c;

	printf("Uzunligi, bo'yi va kengligini kiriting: ");
	scanf("%d %d %d", &a,&b,&c);
	printf("Pralellipedning hajmi %d kubga teng", a*c*b);

	return 0;

}
