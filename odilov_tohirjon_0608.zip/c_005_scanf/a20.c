#include <stdio.h>

int main(){

	int num;

	printf("Faqatgina ikki xonali son kiriting:");
	scanf("%d", &num);
	printf("O'nlar xonasi => %d\n", num/10);
	printf("Birlar xonasi => %d\n", num%10);

	return 0;

}
