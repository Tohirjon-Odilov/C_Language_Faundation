#include <stdio.h>

int main(){

	int num;

	printf("Son kiriting: ");
	scanf("%d", &num); printf("%d ning kvadrati: %d", num, num*num);

	return 0;

}
