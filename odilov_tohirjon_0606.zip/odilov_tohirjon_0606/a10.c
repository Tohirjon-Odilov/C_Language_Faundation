#include <stdio.h>

int main(){

	int a = 2;

	//karra jadvali

	printf("%d * %2d = %2d\n", a, 1, a*1);
	printf("%d * %2d = %2d\n", a, 2, a*2);
	printf("%d * %2d = %2d\n", a, 3, a*3);
	printf("%d * %2d = %2d\n", a, 4, a*4);
	printf("%d * %2d = %2d\n", a, 5, a*5);
	printf("%d * %2d = %2d\n", a, 6, a*6);
	printf("%d * %2d = %2d\n", a, 7, a*7);
	printf("%d * %2d = %2d\n", a, 8, a*8);
	printf("%d * %2d = %2d\n", a, 9, a*9);
	printf("%d * %2d = %2d\n", a, 10, a*10);

	return 0;

}
