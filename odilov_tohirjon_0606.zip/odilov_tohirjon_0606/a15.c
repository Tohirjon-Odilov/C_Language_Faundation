#include <stdio.h>

int main(){

	int month = 29;
	printf("%d yil\n", month/12);

	return 0;

}
