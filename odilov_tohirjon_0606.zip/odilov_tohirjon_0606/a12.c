#include <stdio.h>

int main(){

	int width = 5;
	int height = 2;
	printf("%d\n",2*(width+height));

	return 0;

}
