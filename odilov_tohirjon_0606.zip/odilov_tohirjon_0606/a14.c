#include <stdio.h>

int main(){

	int a = 1;
	printf("%d\n", a);
	printf("%d %d\n", a, a+1);
	printf("%d %d %d\n", a, a+1, a+2);
	printf("%d %d %d %d\n", a, a+1, a+2, a+3);
	printf("%d %d %d %d %d\n", a, a+1, a+2, a+3,a+4);

	return 0;

}
