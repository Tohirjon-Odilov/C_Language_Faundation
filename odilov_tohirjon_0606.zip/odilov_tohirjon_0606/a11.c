#include<stdio.h>

int main(){

	char belgi = '*';
	printf("\n%c\n", belgi);
	printf("%c %c\n", belgi, belgi);
	printf("%c %c %c\n", belgi,belgi,belgi);
	printf("%c %c %c %c\n", belgi, belgi, belgi, belgi);

	return 0;

}
