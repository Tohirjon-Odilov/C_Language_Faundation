#include <stdio.h>

int main(){

	int month2 = 29;
	printf("%d oy\n", month2%12);

	return 0;

}
