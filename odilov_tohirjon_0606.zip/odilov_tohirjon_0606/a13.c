#include <stdio.h>

int main(){

	int a = 192;
	int b = 298;
	int c = 45;

	printf("%d %d %d shu sonlarning o'rta arifmetigi %d\n", a,b,c, (a+b+c)/3);

	return 0;

}
