#include <stdio.h>

int main(){

	int a,b,c;

	printf("Uchburchakning ichki burchaklarini kiriting: ");
	scanf("%d%d%d", &a,&b,&c);

	if(a+b+c == 180){
	 printf("Uchburchak mavjud.");
	}else{
	 printf("Uchburchak mavujd emas.");
	}

	return 0;

}
