#include <stdio.h>

int main(){

	int num;

	printf("Son kiriting: ");
	scanf("%d", &num);

	printf("%d", num * -1);

	return 0;

}
